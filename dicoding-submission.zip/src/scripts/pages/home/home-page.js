import HomePresenter from "../../presenters/home-presenter";

export default class HomePage {
	async render() {
		return `
      <section class="min-h-screen px-4 pt-24 md:px-8 py-6 
                      ext-gray-200 font-mono">

        <!-- HEADER -->
        <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
          <div>
            <h1 class="text-2xl font-bold text-cyan-400 tracking-wide">
              [ STORIES ]
            </h1>
            <h2 class="text-cyan-400 text-sm">
              jelajahi cerita pengguna lain
            </h2>
          </div>

          <a 
            href="#/add-story"
            class="inline-block px-4 py-2 rounded-lg 
                   border border-cyan-400 text-cyan-400
                   hover:bg-cyan-400 hover:text-black
                   transition text-sm font-semibold"
          >
            + EXECUTE NEW
          </a>
        </div>

        <!-- SEARCH -->
        <form id="searchForm" class="mb-6">
          <div class="relative">
            <label for="searchInput" class="sr-only">Search stories</label>
            <input 
              id="searchInput"
              type="text" 
              placeholder="search..."
              class="w-full px-4 py-2 pl-10 rounded-xl text-cyan-400
                     bg-black/40 border border-gray-700
                     focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400
                     outline-none transition text-sm"
            />
            <span class="absolute left-3 top-2 text-cyan-400" aria-hidden="true">⌕</span>
          </div>
        </form>

        <!-- LOADING -->
        <div id="loading" class="text-center text-gray-500 mb-6 animate-pulse">
          loading data...
        </div>

        <!-- EMPTY -->
        <div id="empty" class="hidden text-center text-gray-500 mb-6">
          no data found
        </div>

        <!-- STORIES -->
        <div id="stories" class="grid gap-6 sm:grid-cols-2 lg:grid-cols-3"></div>

      </section>
    `;
	}

	async afterRender() {
		const searchInput = document.getElementById("searchInput");
		const container = document.getElementById("stories");
		const empty = document.getElementById("empty");

		let allStories = [];

		const presenter = new HomePresenter({
			view: {
				showLoading: () => {
					document.getElementById("loading").style.display = "block";
				},

				hideLoading: () => {
					document.getElementById("loading").style.display = "none";
				},

				renderStories: (stories) => {
					allStories = stories;
					this._displayStories(stories);
				},

				showError: (msg) => {
					container.innerHTML = `<p class="text-red-500 text-center col-span-full">${msg}</p>`;
				},
			},
		});

		await presenter.init();

		searchInput.addEventListener("input", (e) => {
			const keyword = e.target.value.toLowerCase().trim();

			if (!keyword) {
				this._displayStories(allStories);
				return;
			}

			const filtered = allStories.filter(
				(story) =>
					story.name.toLowerCase().includes(keyword) ||
					story.description.toLowerCase().includes(keyword),
			);

			this._displayStories(filtered);
		});
	}

	_displayStories(stories) {
		const container = document.getElementById("stories");
		const empty = document.getElementById("empty");

		if (stories.length === 0) {
			empty.classList.remove("hidden");
			container.innerHTML = "";
			return;
		}

		empty.classList.add("hidden");
		container.innerHTML = stories
			.map(
				(story) => `
      <a href="#/stories/${story.id}" class="block h-full">
        <article class="h-full group rounded-2xl overflow-hidden bg-black/40 border border-cyan-500/20 hover:border-cyan-400/40 transition duration-300">
          <div class="relative overflow-hidden">
            <img src="${story.photoUrl}" alt="${story.description} by ${story.name}"
              style="view-transition-name: story-img-${story.id}"
              class="w-full h-48 object-cover opacity-80 group-hover:opacity-100 group-hover:scale-105 transition duration-300" />
            <div class="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
          </div>
          <div class="p-4">
            <h3 class="font-semibold text-lg text-cyan-300 mb-1 truncate">${story.name}</h3>
            <p class="text-sm text-gray-400 line-clamp-3 mb-3">${story.description}</p>
            <div class="flex items-center justify-between text-xs text-gray-500">
              <span>${new Date(story.createdAt).toLocaleString()}</span>
              <span class="text-cyan-400 opacity-70 group-hover:opacity-100 transition">view -></span>
            </div>
          </div>
        </article>
      </a>
    `,
			)
			.join("");
	}
}
